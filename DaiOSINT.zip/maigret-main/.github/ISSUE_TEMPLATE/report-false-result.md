---
name: Report invalid result
about: I want to report invalid result of Maigret search
title: Invalid result
labels: false-result
assignees: soxoj

---

Invalid link: <INSERT LINK HERE>

<!--

Put x into the box

[ ] ==> [x]

-->

- [ ] I'm sure that the link leads to "not found" page
